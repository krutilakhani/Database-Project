CREATE DATABASE  IF NOT EXISTS `mydb` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `mydb`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mydb
-- ------------------------------------------------------
-- Server version	5.7.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bill`
--

DROP TABLE IF EXISTS `bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bill` (
  `BillId` int(11) NOT NULL,
  `Price` double DEFAULT NULL,
  `Payment_PayId` int(11) NOT NULL,
  PRIMARY KEY (`BillId`,`Payment_PayId`),
  KEY `fk_Bill_Payment1_idx` (`Payment_PayId`),
  CONSTRAINT `fk_Bill_Payment1` FOREIGN KEY (`Payment_PayId`) REFERENCES `payment` (`PayId`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill`
--

LOCK TABLES `bill` WRITE;
/*!40000 ALTER TABLE `bill` DISABLE KEYS */;
/*!40000 ALTER TABLE `bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chef`
--

DROP TABLE IF EXISTS `chef`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chef` (
  `Speciality` varchar(45) DEFAULT NULL,
  `Person_ID` int(11) NOT NULL,
  PRIMARY KEY (`Person_ID`),
  CONSTRAINT `fk_Chef_Person1` FOREIGN KEY (`Person_ID`) REFERENCES `person` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chef`
--

LOCK TABLES `chef` WRITE;
/*!40000 ALTER TABLE `chef` DISABLE KEYS */;
INSERT INTO `chef` VALUES ('Indian',7),('Italian',8),('Chinese',9);
/*!40000 ALTER TABLE `chef` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `food`
--

DROP TABLE IF EXISTS `food`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `food` (
  `FoodNo` int(11) NOT NULL,
  `HotelAttendant_Person_ID` int(11) DEFAULT NULL,
  `Chef_Person_ID` int(11) DEFAULT NULL,
  `Quantity` varchar(45) DEFAULT NULL,
  `Price` double DEFAULT NULL,
  `reservationline_Reservation_ReservationID` int(11) DEFAULT NULL,
  PRIMARY KEY (`FoodNo`),
  KEY `fk_Food_HotelAttendant1_idx` (`HotelAttendant_Person_ID`),
  KEY `fk_Food_Chef1_idx` (`Chef_Person_ID`),
  KEY `fk_food_reservationline1_idx` (`reservationline_Reservation_ReservationID`),
  CONSTRAINT `fk_Food_Chef1` FOREIGN KEY (`Chef_Person_ID`) REFERENCES `chef` (`Person_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Food_HotelAttendant1` FOREIGN KEY (`HotelAttendant_Person_ID`) REFERENCES `hotelattendant` (`Person_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_food_reservationline1` FOREIGN KEY (`reservationline_Reservation_ReservationID`) REFERENCES `reservationline` (`Reservation_ReservationID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food`
--

LOCK TABLES `food` WRITE;
/*!40000 ALTER TABLE `food` DISABLE KEYS */;
INSERT INTO `food` VALUES (1,NULL,7,'10',10,201);
/*!40000 ALTER TABLE `food` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `mydb`.`food_AFTER_INSERT` AFTER INSERT ON `food` FOR EACH ROW
BEGIN
UPDATE reservationline 
SET reservationline.Subtotal =( reservationline.subtotal + NEW.price)
 WHERE Reservation_ReservationID = NEW.reservationline_reservation_reservationID;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `guest`
--

DROP TABLE IF EXISTS `guest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guest` (
  `Person_ID` int(11) NOT NULL,
  `HotelAttendant_Person_ID` int(11) DEFAULT NULL,
  `Check_In_date` date DEFAULT NULL,
  `Checkout_date` date DEFAULT NULL,
  PRIMARY KEY (`Person_ID`),
  KEY `fk_Guest_HotelAttendant1_idx` (`HotelAttendant_Person_ID`),
  CONSTRAINT `fk_Guest_HotelAttendant1` FOREIGN KEY (`HotelAttendant_Person_ID`) REFERENCES `hotelattendant` (`Person_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Guest_Person1` FOREIGN KEY (`Person_ID`) REFERENCES `person` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guest`
--

LOCK TABLES `guest` WRITE;
/*!40000 ALTER TABLE `guest` DISABLE KEYS */;
INSERT INTO `guest` VALUES (1,NULL,'2017-02-11','2017-02-15'),(2,NULL,'2017-04-17','2017-04-29'),(3,NULL,'2017-09-25','2017-09-30'),(13,NULL,'2017-12-12','2017-12-15'),(14,NULL,'2017-12-12','2017-12-30');
/*!40000 ALTER TABLE `guest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `guest_bookings`
--

DROP TABLE IF EXISTS `guest_bookings`;
/*!50001 DROP VIEW IF EXISTS `guest_bookings`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `guest_bookings` AS SELECT 
 1 AS `Person_ID`,
 1 AS `name`,
 1 AS `Contactno`,
 1 AS `count(ReservationID)`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `guestlog`
--

DROP TABLE IF EXISTS `guestlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guestlog` (
  `GuestId` int(11) DEFAULT NULL,
  `Manager_Person_ID` int(11) DEFAULT NULL,
  KEY `fk_GuestLog_Manager1_idx` (`Manager_Person_ID`),
  CONSTRAINT `fk_GuestLog_Manager1` FOREIGN KEY (`Manager_Person_ID`) REFERENCES `manager` (`Person_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guestlog`
--

LOCK TABLES `guestlog` WRITE;
/*!40000 ALTER TABLE `guestlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `guestlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotelattendant`
--

DROP TABLE IF EXISTS `hotelattendant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hotelattendant` (
  `Experience` varchar(45) DEFAULT NULL,
  `Person_ID` int(11) NOT NULL,
  PRIMARY KEY (`Person_ID`),
  CONSTRAINT `fk_HotelAttendant_Person1` FOREIGN KEY (`Person_ID`) REFERENCES `person` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotelattendant`
--

LOCK TABLES `hotelattendant` WRITE;
/*!40000 ALTER TABLE `hotelattendant` DISABLE KEYS */;
INSERT INTO `hotelattendant` VALUES ('7 years',10),('1 year',11),('5 years',12);
/*!40000 ALTER TABLE `hotelattendant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manager`
--

DROP TABLE IF EXISTS `manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manager` (
  `Person_ID` int(11) NOT NULL,
  `SKillsets` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Person_ID`),
  CONSTRAINT `fk_Manager_Person` FOREIGN KEY (`Person_ID`) REFERENCES `person` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manager`
--

LOCK TABLES `manager` WRITE;
/*!40000 ALTER TABLE `manager` DISABLE KEYS */;
INSERT INTO `manager` VALUES (4,'Relationship BUilding skills'),(5,'Time management'),(6,'Organisation skills');
/*!40000 ALTER TABLE `manager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment` (
  `PayId` int(11) NOT NULL AUTO_INCREMENT,
  `Guest_Person_ID` int(11) NOT NULL,
  `reservationline_Reservation_ReservationID` int(11) NOT NULL,
  `Tax` double DEFAULT NULL,
  `TotalAmount` double DEFAULT NULL,
  PRIMARY KEY (`PayId`),
  KEY `fk_Payment_Guest1_idx` (`Guest_Person_ID`),
  KEY `fk_payment_reservationline1_idx` (`reservationline_Reservation_ReservationID`),
  CONSTRAINT `fk_Payment_Guest1` FOREIGN KEY (`Guest_Person_ID`) REFERENCES `guest` (`Person_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_payment_reservationline1` FOREIGN KEY (`reservationline_Reservation_ReservationID`) REFERENCES `reservationline` (`Reservation_ReservationID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES (1,1,201,100,1310),(2,1,201,100,1310),(3,1,201,100,1310);
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `mydb`.`payment_AFTER_INSERT` AFTER INSERT ON `payment` FOR EACH ROW
BEGIN
update Reservation
       set Reservation_paid = 'yes'
       where new.Guest_Person_ID= reservation.Guest_Person_ID and
       new.Reservationline_reservation_reservationID = reservation.ReservationID;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `person`
--

DROP TABLE IF EXISTS `person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `person` (
  `ID` int(11) NOT NULL,
  `Name` varchar(45) DEFAULT NULL,
  `ContactNo` varchar(45) DEFAULT NULL,
  `Gender` varchar(45) DEFAULT NULL,
  `Type` enum('Manager','Guest','Chef','HotelAttendant') DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person`
--

LOCK TABLES `person` WRITE;
/*!40000 ALTER TABLE `person` DISABLE KEYS */;
INSERT INTO `person` VALUES (1,'John','9673215046','Male','Guest'),(2,'Jane','9683215046','Female','Guest'),(3,'Ann','8873215046','Female','Guest'),(4,'Stefan','8073215046','Male','Manager'),(5,'Ravi','8877815046','Male','Manager'),(6,'Casy','1173215046','Female','Manager'),(7,'Renita','6673215046','Female','Chef'),(8,'Rosy','8873215466','Female','Chef'),(9,'Joseph','8789423046','Male','Chef'),(10,'Lennard','9996215046','Male','HotelAttendant'),(11,'Andrew','8052821046','Male','HotelAttendant'),(12,'Rose','0236115046','Female','HotelAttendant'),(13,'MAyank','0236115046','Female','Guest'),(14,'Jacke','0236115046','Male','Guest');
/*!40000 ALTER TABLE `person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `premium`
--

DROP TABLE IF EXISTS `premium`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `premium` (
  `Amenities` varchar(45) DEFAULT NULL,
  `Room_RoomNo` int(11) NOT NULL,
  `Room_Reservation_BookingId` int(11) NOT NULL,
  `Size` varchar(200) DEFAULT NULL,
  `noofbeds` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`Room_RoomNo`),
  CONSTRAINT `fk_Deluxe_Room1` FOREIGN KEY (`Room_RoomNo`) REFERENCES `room` (`RoomNo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `premium`
--

LOCK TABLES `premium` WRITE;
/*!40000 ALTER TABLE `premium` DISABLE KEYS */;
INSERT INTO `premium` VALUES ('breakfast included',102,204,'150 sq ft','2'),('free spa',104,205,'140 sq ft','2');
/*!40000 ALTER TABLE `premium` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservation` (
  `ReservationID` int(11) NOT NULL,
  `TimeDate` timestamp NULL DEFAULT NULL,
  `Guest_Person_ID` int(11) NOT NULL,
  `Reservation_paid` varchar(3) DEFAULT 'NO',
  PRIMARY KEY (`ReservationID`),
  KEY `fk_Reservation_Guest1_idx` (`Guest_Person_ID`),
  CONSTRAINT `fk_Reservation_Guest1` FOREIGN KEY (`Guest_Person_ID`) REFERENCES `guest` (`Person_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
INSERT INTO `reservation` VALUES (201,'2017-02-11 05:00:12',1,'yes'),(202,'2017-04-17 04:00:12',1,'NO'),(203,'2017-02-11 05:00:12',2,'NO'),(204,'2017-02-11 05:00:12',3,'NO'),(205,'2017-02-11 05:00:12',1,'NO'),(206,'2017-06-11 04:00:12',2,'NO');
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservationline`
--

DROP TABLE IF EXISTS `reservationline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservationline` (
  `Room_RoomNo` int(11) NOT NULL,
  `Reservation_ReservationID` int(11) NOT NULL,
  `No_of_rooms` varchar(45) DEFAULT NULL,
  `Subtotal` double DEFAULT NULL,
  PRIMARY KEY (`Reservation_ReservationID`),
  KEY `fk_Room_has_Reservation_Reservation1_idx` (`Reservation_ReservationID`),
  KEY `fk_Room_has_Reservation_Room1_idx` (`Room_RoomNo`),
  CONSTRAINT `fk_Room_has_Reservation_Reservation1` FOREIGN KEY (`Reservation_ReservationID`) REFERENCES `reservation` (`ReservationID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Room_has_Reservation_Room1` FOREIGN KEY (`Room_RoomNo`) REFERENCES `room` (`RoomNo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservationline`
--

LOCK TABLES `reservationline` WRITE;
/*!40000 ALTER TABLE `reservationline` DISABLE KEYS */;
INSERT INTO `reservationline` VALUES (101,201,'1',1210),(102,202,'8',16000),(103,203,'9',10800),(104,204,'10',20000),(105,205,'11',22000);
/*!40000 ALTER TABLE `reservationline` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ALLOW_INVALID_DATES,ERROR_FOR_DIVISION_BY_ZERO,TRADITIONAL,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `mydb`.`reservationline_BEFORE_INSERT` BEFORE INSERT ON `reservationline` FOR EACH ROW
BEGIN
declare no_of_rooms  INTEGER;
    declare Price DECIMAL(8,2);
    
 SET @no_of_rooms = (Select r.Available From room r WHERE r.RoomNo = NEW.Room_RoomNo);
    
 IF NEW.No_of_rooms > @no_Of_rooms THEN
    
 SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Rooms not available';
    
 ELSEIF NEW.No_of_rooms <= @no_of_rooms THEN
    
 UPDATE room
    SET Available = @no_of_rooms - NEW.No_of_rooms
    WHERE room.RoomNo = NEW.Room_RoomNo;
    
 SET @price = (Select r.Price From room r WHERE r.RoomNo = NEW.Room_RoomNo);
    
 
    SET NEW.Subtotal = NEW.No_of_rooms * @price;
    
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room` (
  `RoomNo` int(11) NOT NULL,
  `Location` varchar(45) DEFAULT NULL,
  `Manager_Person_ID` int(11) NOT NULL,
  `Type` enum('Standard','Premium') DEFAULT NULL,
  `Checkin` date DEFAULT NULL,
  `Checkout` date DEFAULT NULL,
  `Price` int(11) DEFAULT NULL,
  `Available` int(11) DEFAULT NULL,
  PRIMARY KEY (`RoomNo`),
  KEY `fk_Room_Manager1_idx` (`Manager_Person_ID`),
  CONSTRAINT `fk_Room_Manager1` FOREIGN KEY (`Manager_Person_ID`) REFERENCES `manager` (`Person_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (101,'Firstfloor',4,'Standard','2017-02-11','2017-02-13',1200,9),(102,'Secondfloor',6,'Premium','2017-03-11','2017-02-15',2000,7),(103,'Firstfloor',5,'Standard','2017-04-17','2017-04-29',1200,2),(104,'Groundfloor',4,'Premium','2017-05-01','2017-05-13',2000,1),(105,'Firstfloor',4,'Premium','2017-09-25','2017-09-27',2000,0),(106,'Secondfloor',6,'Standard','2017-02-19','2017-02-13',1200,11),(107,'Firstfloor',4,'Standard','2017-12-11','2017-12-13',1200,10),(108,'Second Room',5,'Standard','2017-12-09','2017-12-17',1200,10),(109,'Firstfloor',4,'Premium','2017-12-07','2017-12-14',1500,1);
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `standard`
--

DROP TABLE IF EXISTS `standard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `standard` (
  `Size` varchar(45) DEFAULT NULL,
  `Number of beds` varchar(45) DEFAULT NULL,
  `Room_RoomNo` int(11) NOT NULL,
  `Room_Reservation_BookingId` int(11) NOT NULL,
  PRIMARY KEY (`Room_RoomNo`),
  CONSTRAINT `fk_Single or Twin_Room1` FOREIGN KEY (`Room_RoomNo`) REFERENCES `room` (`RoomNo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `standard`
--

LOCK TABLES `standard` WRITE;
/*!40000 ALTER TABLE `standard` DISABLE KEYS */;
INSERT INTO `standard` VALUES ('100 sq ft','1',101,201),('100 sq ft','1',103,202),('100 sq ft','1',106,203);
/*!40000 ALTER TABLE `standard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `todaycustomers`
--

DROP TABLE IF EXISTS `todaycustomers`;
/*!50001 DROP VIEW IF EXISTS `todaycustomers`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `todaycustomers` AS SELECT 
 1 AS `Person_ID`,
 1 AS `Name`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'mydb'
--

--
-- Dumping routines for database 'mydb'
--
/*!50003 DROP PROCEDURE IF EXISTS `get_available_rooms` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_available_rooms`(IN o_room_type varchar(40), IN o_checkin_date date, IN o_checkout_date date)
BEGIN
SELECT roomno, available, Type FROM room WHERE Type=o_room_type AND NOT EXISTS (
SELECT room_roomno FROM reservationline
 WHERE reservationline.Room_RoomNo=room.RoomNo AND checkout >= o_checkin_date AND checkin <= o_checkout_date
);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_Today_Guests_lists` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_Today_Guests_lists`(IN today_date date)
BEGIN
SELECT Person_ID, Name FROM reservation  , guest, person WHERE checkout_date >= today_date AND check_in_date <= today_date and guest.Person_ID = person.ID 
group by Name, Person_ID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `payment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `payment`(in guestid int , in reservationid int,in t int )
begin
insert into payment(guest_person_id,reservationline_reservation_reservationid,tax,totalAmount) values(guestid,reservationid,t,(
select (subtotal + t) from reservationline where Reservation_ReservationID= reservationid));
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `guest_bookings`
--

/*!50001 DROP VIEW IF EXISTS `guest_bookings`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `guest_bookings` AS select `g`.`Person_ID` AS `Person_ID`,`p`.`Name` AS `name`,`p`.`ContactNo` AS `Contactno`,count(`r`.`ReservationID`) AS `count(ReservationID)` from ((`reservation` `r` join `guest` `g`) join `person` `p` on(((`r`.`Guest_Person_ID` = `g`.`Person_ID`) and (`g`.`Person_ID` = `p`.`ID`)))) group by `g`.`Person_ID` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `todaycustomers`
--

/*!50001 DROP VIEW IF EXISTS `todaycustomers`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `todaycustomers` AS select `guest`.`Person_ID` AS `Person_ID`,`person`.`Name` AS `Name` from ((`reservation` join `guest`) join `person`) where ((`guest`.`Checkout_date` >= curdate()) and (`guest`.`Check_In_date` <= curdate()) and (`guest`.`Person_ID` = `person`.`ID`)) group by `person`.`Name`,`guest`.`Person_ID` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-14  0:53:54
